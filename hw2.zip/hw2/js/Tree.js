/** Class representing a Tree. */
class Tree {
  nodes;
  /**
   * Creates a Tree Object
   * Populates a single attribute that contains a list (array) of Node objects to be used by the other functions in this class
   * @param {json[]} json - array of json objects with name and parent fields
   */
  constructor(json) 
  {
    this.nodes = [];

    for(let node of json )
    {
      this.nodes.push(new Node(node.name, node.parent));
    }

    for(let node of this.nodes)
    {
      node.parentNode = this.nodes.find(function(n){
          n.name === node.parentName
      });
    }
  }

  /**
   * Assign other required attributes for the nodes.
   */
  buildTree () 
  {
    // note: in this function you will assign positions and levels by making calls to assignPosition() and assignLevel()
    for(let node of this.nodes)
    {
      node.children = this.nodes.filter(function(n){ 
          if (n.parentName === node.name)
          {
            return n; 
          }
      });
    }
    this.assignLevel(this.nodes.find(function(n){
      if (n.parentName === 'root')
      {
        return n; 
      }
    }), 0);
    this.assignPosition(this.nodes.find(function(n){
        if (n.parentName === 'root')
        {
          return n; 
        }
      }), 0);
  }

  /**
   * Recursive function that assign levels to each node
   */
  assignLevel (node, level) 
  {
    node.level = level;

    for(let child of node.children)
    {
      this.assignLevel(child, level + 1);
    }
  }

  /**
   * Recursive function that assign positions to each node
   */
  assignPosition (node, position) 
  {
    node.position = position; 

    for(let child of node.children)
    {
      let temp = this.assignPosition(child, position);

      if (temp > position + 1)
      {
        position = temp;
      }
      else 
      {
        position += 1; 
      }
    }
    return position;
  }

  /**
   * Function that renders the tree
   */
  renderTree () {
    let svg = d3.select('body').append('svg').attr('width', 1200).attr('height',1200);
    let radius = 50;
    let edge = radius + 100;

    for(let node of this.nodes)
    {
      for(let child of node.children)
      {
        svg.append('line').attr('x1',((node.level *edge)+radius)).attr('x2',((child.level *edge)+radius)).attr('y1',((node.position *edge)+radius)).attr('y2',((child.position *edge)+radius));
      }
      let g = svg.append('g').attr('transform', "translate("+((node.level *edge)+radius)+","+((node.position *edge)+radius)+")");

      g.append('circle').attr('r',radius);

      g.append('text').attr('class', 'label').text(node.name);
    }
  }
}